# Planilla Quincenal para Android

Este es el proyecto fuente de Android (WebView local) listo para abrirse y compilarse con Android Studio. No es todavía un APK compilado.

## Compilar el APK
1. Instala Android Studio y el Android SDK Platform 35.
2. Abre esta carpeta en Android Studio.
3. Espera a que Gradle sincronice y elige **Build > Build APK(s)**.
4. Android Studio mostrará la ubicación del APK en el panel de notificaciones; normalmente `app/build/outputs/apk/debug/app-debug.apk`.

La aplicación guarda datos localmente en el dispositivo usando almacenamiento del navegador. Exporta copias de seguridad desde la propia app con regularidad. Desinstalar o borrar los datos de la app puede borrar los registros locales.

## Compilación en la nube (sin computadora propia)
El proyecto incluye un flujo de GitHub Actions (`.github/workflows/android.yml`) que puede compilar el APK en servidores de GitHub una vez que el proyecto esté en un repositorio. En la pestaña **Actions**, ejecuta **Compilar APK Android** y descarga el artefacto `PlanillaQuincenal-APK`. Requiere una cuenta de GitHub y subir el contenido del proyecto a un repositorio.
